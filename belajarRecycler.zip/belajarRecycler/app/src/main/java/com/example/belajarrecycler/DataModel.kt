package com.example.belajarrecycler

data class DataModel(var title : String, var desc : String, var image : Int) {
}